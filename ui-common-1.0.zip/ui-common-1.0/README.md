ui-common -- Teachscape UI Elements
=========

## Description

The ui-common repository holds the user interface elements that are used across Teachscape mobile and desktop web products. Elements include CSS stylesheets, browser Javascript code, HTML templates and partials, and any other relevant UI elements.

This project should be used as a starting point for building style elements in Teachscape products. Any code that can potentially be shared across projects should be added here. Custom styling specific to individual products can be written inside the project repositories.

## Getting Started

Teachscape uses the Bower (http://bower.io/) Javascript-based package manager to import dependencies into projects. To se the common UI, install Bower in your project and add this repository to your bower.json file (requires access to the Teachscape Github repositories):

```json
{
  "name": "play-scala-example",
  "version": "0.0.1",
  "homepage": "https://github.com/Teachscape/play-app-example",
  "authors": [
    "Lionel Jingles <lionel.jingles@teachscape.com>"
  ],
 "dependencies": {
    "ui-common": "git@github.com:Teachscape/ui-common.git"
  }
}
```

Then install the dependency using Bower inside your project directory:

```bash
$ bower install ui-common
```

Once installed, you will be able to include elements from inside your project, for example (requires LESS support):

```less
@import (less) "/path/to/bower/components/ui-common/css/main.less";
```

## Updates

This project is being developed and will be updated frequently as the Teachscape design and development process is put into place. Check back here frequently for updates.